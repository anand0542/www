﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
using SampleApplication.Controllers;
namespace SampleApplication.Tests.Controllers
{
    [TestClass]
    public class PeopleControllerTest
    {
        [TestMethod]
        public void TestIndex()
        {
            // Arrange
            PeopleController controller = new PeopleController();
            // Act
            ViewResult result = controller.Index() as ViewResult;
            // Assert
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public void TestDetailsView()
        {
            PeopleController controller = new PeopleController();
            ViewResult result = controller.Details(2) as ViewResult;
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public void TestCreateView()
        {
            PeopleController controller = new PeopleController();
            ViewResult result = controller.Create() as ViewResult;
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TestEditView()
        {
            PeopleController controller = new PeopleController();
            ViewResult result = controller.Edit(2) as ViewResult;
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TestDeleteView()
        {
            var controller = new PeopleController();
            var result = controller.Delete(2) as ViewResult;
            Assert.IsNotNull(result);
        }

    }
}
