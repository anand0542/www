﻿using SampleApplication.Entities;
using SampleApplication.Models;
using System.Web.Mvc;

/*
Date 4/27/2020

Build a very small MVC application that perform CRUD operation on Mockup data

Artifacts
Solution Name SampleApplication
Project Name SampleApplication.csproj
	• Controller
		○ People - Driving peopledate from people Controller
	• View
		○ Index - Display List of Item  
		○ Create -View Page for Create item
		○ Edit -  View Page for Update item
		○ Detail -View Page Item detail
		○ Delete -Page for Delate item
	• Model 
		○ PersonWrapper  List of persons
		○ PersonDto - Person  properties  
	• Entities 
		○ Interface Class
			§ IPerson - Declare Interface Method for CRUD Operation
		○ Implementation Class
			§ Person - Implement interface for CRUD operation
				□ GetItems- Mock up List Items 
				□ GetPeople- Get ALL Items.
				□ GetPeopleById - Get Item by Id
				□ PostPerson() - Create Item
				□ DeletePerson() - Delete Item
				□ PutPerson() - Update Item
	• RouteConfig - Mapped to People Index page    
    • Project Name SampleApplication.csproj.Tests
        • PeopleControllerTest
    • Rest of Pages/Files are auto generated.
 
*/

namespace SampleApplication.Controllers
{
    public class PeopleController : Controller
    {
        #region Constants
        private readonly IPerson _repository;
        #endregion

        public PeopleController()
        {
            _repository=new Person();
        }
        /// <summary>
        /// Get Item
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Index()
        {
            var response =  _repository.GetPeople();
            return View(response.PersonDto);
        }

        // GET: People/Details/5
        [HttpGet]
        public ActionResult Details(int Id)
        {
            var response = _repository.GetPeople(Id);
            return View(response);
        }

        // GET: Test/Create
        public ActionResult Create()
        {
            return View();
        }
        // POST: People/Create
        [HttpPost]
        public ActionResult Create(PersonDto request)
        {
            try
            {
                // TODO: Add insert logic here
                var response = _repository.PostPerson(request);
                return View("Index", response.PersonDto);
               // return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Test/Edit/5
        public ActionResult Edit(int Id)
        {
            var response = _repository.GetPeople(Id);
            return View(response);
        }

        // POST: People/Edit/5
        [HttpPost]
        public ActionResult Edit(PersonDto request)
        {
            try
            {
                // TODO: Add update logic here
                var response = _repository.PutPerson(request);
                return View("Index", response.PersonDto);              
            }
            catch
            {
                return View();
            }
        }

        // GET: Test/Delete/5
        public ActionResult Delete(int Id)
        {
            var response = _repository.GetPeople(Id);
            return View(response);
        }

        // POST: People/Delete/5
        [HttpPost]
        public ActionResult Delete(PersonDto request)
        {
            try
            {
                // TODO: Add delete logic here
                var response = _repository.DeletePerson(request.Id);
                return View("Index", response.PersonDto);
            }
            catch
            {
                return View();
            }
        }
    }
}
