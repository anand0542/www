﻿namespace SampleApplication.Models
{
    public class PersonDto
    {
        public PersonDto()
        {
            Id = 0;
            FirstName = string.Empty;
            LastName =  string.Empty;        
        } 

        public PersonDto(PersonDto person)
        {
            Id = person.Id;
            FirstName = person.FirstName;
            LastName = person.LastName;
        }

        /// <summary>
        /// id
        /// </summary> 
        public int Id { get; set; }
        /// <summary>
        /// FirstName
        /// </summary>
        public string FirstName { get; set; }
        /// <summary>
        /// LastName
        /// </summary>
        public string LastName { get; set; }
    }
}