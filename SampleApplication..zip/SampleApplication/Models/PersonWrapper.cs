﻿using System.Collections.Generic;

namespace SampleApplication.Models
{
    public class PersonWrapper
    {
        public PersonWrapper()
        {            
            PersonDto = new List<PersonDto>();            
        }
        public IList<PersonDto> PersonDto
        {
            get;
            set;
        }

    }
}