﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SampleApplication.Models;

namespace SampleApplication.Entities
{
    public interface IPerson
    {
        PersonWrapper GetPeople();
        PersonDto GetPeople(int Id);
        PersonWrapper PostPerson(PersonDto request);
        PersonWrapper PutPerson(PersonDto Id);
        PersonWrapper DeletePerson(int Id);
    }
}
