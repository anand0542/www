﻿
using SampleApplication.Models;
using System.Linq;

/*
  Implementation Class
			§ Person - Implement interface for CRUD operation
				□ GetList- Mock up List Items 
				□ GetPeople- Get ALL Items.
				□ GetPeopleById - Get Item by Id
				□ PostPerson() - Create Item
				□ DeletePerson() - Delete Item
				□ PutPerson() - Update Item  
  */
namespace SampleApplication.Entities
{
    public class Person : IPerson
    {
        /// <summary>
        /// We can 
        /// </summary>
        //string con = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;
        //Also WEb API call.

        /// <summary>
        /// Mock List 
        /// </summary>
        /// <returns></returns>
        /// 
       // PersonWrapper peoplelst = new PersonWrapper();

       
        private PersonWrapper GetList()
        {
            var people = new PersonWrapper();
            people.PersonDto.Add(new PersonDto { FirstName = "Anand", LastName = "Agrawal", Id = 1 });
            people.PersonDto.Add(new PersonDto { FirstName = "Satya", LastName = "Nadela", Id = 2 });
            people.PersonDto.Add(new PersonDto { FirstName = "Bill", LastName = "Gates", Id = 3 });
            return people;
        }
        /// <summary>
        /// Get Items
        /// </summary>
        /// <returns></returns>
        public PersonWrapper GetPeople()
        {
            var people = GetList();
            return people;
        }

        public PersonDto GetPeople(int Id)
        {
            var people = GetList();
            return people.PersonDto.Where(x => x.Id == Id).FirstOrDefault();
        }
        /// <summary>
        /// Create item
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        /// <returns></returns>
        public PersonWrapper PostPerson(PersonDto request)
        {
            var people = GetList();
            people.PersonDto.Add(request);
            return people;
        }
        /// <summary>
        /// Update item
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public PersonWrapper PutPerson(PersonDto request)
        {
            var people = GetList();
            people.PersonDto.Single(x => x.Id == request.Id).FirstName = request.FirstName;
            people.PersonDto.Single(x => x.Id == request.Id).LastName = request.LastName;
            return people;
        }
        /// <summary>
        /// Delete Item
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public PersonWrapper DeletePerson(int Id)
        {
            var people = GetList();
            var itemToRemove = people.PersonDto.Single(r => r.Id == Id);
            people.PersonDto.Remove(itemToRemove);
            return people;
        }

    }
}
