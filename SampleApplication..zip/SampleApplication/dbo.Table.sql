﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [FirstName] VARBINARY(50) NULL, 
    [LastNamr] VARBINARY(50) NULL
)
